"""Tiny static server for the portable Wofgue.io build.
Run:  python3 serve.py          (opens on http://localhost:8000)
"""
import http.server, socketserver, webbrowser, os

PORT = 8000
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "site"))
handler = http.server.SimpleHTTPRequestHandler
socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(("0.0.0.0", PORT), handler) as httpd:
    print(f"Wofgue.io running at http://localhost:{PORT}  (Ctrl+C to stop)")
    webbrowser.open(f"http://localhost:{PORT}")
    httpd.serve_forever()
